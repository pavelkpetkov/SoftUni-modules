//TODO Update database name to match project requirements 

module.exports = {
    PORT: 3000,
    DB_CONNECTION_STRING: 'mongodb://localhost:27017/RealEstate',
    TOKEN_SECRET: 'this is very secure11',
    COOKIE_NAME: 'SESSION_TOKEN'
};